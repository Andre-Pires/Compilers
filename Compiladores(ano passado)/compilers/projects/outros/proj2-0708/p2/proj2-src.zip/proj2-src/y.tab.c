#include <sys/cdefs.h>
#ifndef lint
#if 0
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#else
__IDSTRING(yyrcsid, "$NetBSD: skeleton.c,v 1.14 1997/10/20 03:41:16 lukem Exp $");
#endif
#endif
#include <stdlib.h>
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYLEX yylex()
#define YYEMPTY -1
#define yyclearin (yychar=(YYEMPTY))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "yacc2.y"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "./lib/node.h"
#include "./lib/tabid.h"
#include <string.h>

extern FILE *yyin;
extern int *yylineno;
int yyerror(char* e);
void evaluate(Node *p);

typedef struct info_ {
	unsigned int decl;
	unsigned int stat;
	unsigned int bina;
	char* name;
} info;

typedef struct list_el_ {
	info* info;
	struct list_el_* next;
}list_el;

typedef struct list_info_ {
	struct list_el_* first;
	struct list_el_* last;
} list_info;

void printList(list_info* list);
list_el* newFunction(Node* p);
void checkNodes(Node* p, list_el* el);
list_el* createEl();
int addList(list_info* list , list_el* new);
int checkFunction(Node *p);
char* getFunctionName(Node* p);

#line 41 "yacc2.y"
typedef union {
	int i;
	char* s;
	struct typeNode *n;
} YYSTYPE;
#line 64 "y.tab.c"
#define IDENTIFIER 257
#define CONSTANT 258
#define SIZEOF 259
#define PTR_OP 260
#define ARRAY_OP 261
#define GT_OP 262
#define LT_OP 263
#define GE_OP 264
#define LE_OP 265
#define NE_OP 266
#define EQ_OP 267
#define AND_OP 268
#define OR_OP 269
#define TYPEDEF 270
#define INT 271
#define CHAR 272
#define VOID 273
#define STRUCT 274
#define IF 275
#define ELSE 276
#define WHILE 277
#define RETURN 278
#define FUNCTION 279
#define DECLARATION 280
#define TYPE_SPECIFIER 281
#define DECLARATOR 282
#define FUNCTION_DEFINITION 283
#define TYPEDEF_STRUCT 284
#define STRUCT_DECL_LIST 285
#define DIRECT_DECL 286
#define ARRAY_DECL 287
#define PARAM 288
#define COMPOUND 289
#define DECL 290
#define STATE 291
#define NEG 292
#define AST 293
#define FUNC 294
#define EXPR_LIST 295
#define PROGRAM 296
#define EXPR 297
#define C_STATE 298
#define IF_PREC 299
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    1,    1,    1,    1,    2,    2,    3,    4,    4,
    4,    4,    4,    4,    4,    5,    5,    6,    6,    7,
    7,    7,    7,    8,    8,    9,    9,    9,    9,    9,
    9,    9,   10,   10,   11,   12,   12,   12,   12,   13,
   13,   14,   14,   15,   15,   15,   15,   15,   15,   15,
   15,   15,   15,   15,   15,   15,   15,   19,   19,   19,
   16,   16,   16,   16,   16,   16,   16,   16,   18,   18,
   17,   17,   17,   17,
};
short yylen[] = {                                         2,
    1,    1,    2,    1,    2,    2,    3,    3,    1,    1,
    1,    2,    5,    6,    7,    3,    4,    2,    1,    1,
    4,    3,    4,    2,    4,    1,    1,    1,    4,    5,
    3,    2,    5,    7,    3,    1,    1,    2,    0,    1,
    2,    2,    1,    1,    3,    3,    3,    3,    3,    3,
    3,    3,    3,    3,    3,    3,    3,    1,    3,    0,
    1,    2,    2,    2,    2,    2,    3,    4,    1,    3,
    1,    1,    4,    4,
};
short yydefred[] = {                                      0,
    0,   10,   11,    9,    0,    0,    1,    0,    0,    0,
    0,    0,    5,    3,    0,    6,    0,    0,    0,    0,
    0,    0,    0,    0,    7,    0,    8,    0,    0,    0,
    0,    0,    0,    0,   71,    0,    0,    0,    0,   28,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   26,
   27,    0,    0,   37,    0,    0,   61,   22,    0,    0,
    0,    0,    0,   13,   23,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   64,    0,   62,   63,   65,   66,
   41,    0,   42,   35,   38,   32,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   21,    0,    0,   14,    0,   67,    0,    0,    0,    0,
    0,    0,   31,   57,   50,   49,   52,   51,   53,   54,
   55,   56,   47,    0,   45,   46,   48,    0,   15,   17,
    0,    0,   74,   68,   73,    0,    0,   29,   25,   70,
   59,    0,   30,    0,   34,
};
short yydgoto[] = {                                       6,
    7,    8,    9,   30,   31,   18,   19,   60,   49,   50,
   51,   52,   53,   54,   55,   73,   57,  106,  108,
};
short yysindex[] = {                                   -114,
 -221,    0,    0,    0, -226,    0,    0, -114, -114,  -41,
 -111,  -52,    0,    0,  -18,    0, -182,  -42,   43,  -34,
 -114, -114, -159,   43,    0,  -38,    0,  -12, -114,  -33,
  -24,  -22,   11,  -37,    0,   66,   77,   81,   69,    0,
 -243,   69, -243, -243, -243, -243, -114,  -41,   -4,    0,
    0,    3,   -4,    0,   71,   35,    0,    0,  -33,   92,
    9,   76, -120,    0,    0, -119,   69,   69, -114,   69,
   69,   83,   55,  100,    0,  104,    0,    0,    0,    0,
    0,   88,    0,    0,    0,    0,   82,   82,   82,   82,
   82,   82,   82,   82,   82,   69,   82,   82,   82,  117,
    0, -116, -114,    0, -112,    0,  118,  122,   73,  130,
  131,  132,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  115,    0,    0,    0, -114,    0,    0,
 -119,   69,    0,    0,    0,   -4,   -4,    0,    0,    0,
    0, -101,    0,   -4,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,  176,  177,    0,
    0,  -19,    0,    0,    6,    0,    0,    0,   20,    0,
    0,    0,    0,   46,    0,   53,    0,    0,    0,    0,
    0,    0,    0,   15,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  -32,    0,   54,    0,
    0,    0,   56,    0,    0,  121,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  141,    0,    0,    0,
    0,    0,   51,   15,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  142,
    0,    0,   59,    0,   25,    0,  144,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  141,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  -10,    0,    0,    0,
};
short yygindex[] = {                                      0,
   17,   16,    0,  123,   23,  -11,  169,   60,  -93,    0,
  171,    0,  140,  -29,   97,  259,  109,   63,   58,
};
#define YYTABLESIZE 403
short yytable[] = {                                      46,
   17,   42,   67,   41,   43,   40,   44,   40,   17,   40,
   40,   21,   40,   74,   35,   36,   25,   16,   62,   83,
   40,   12,   12,   85,   13,   14,   40,   33,   58,   33,
   12,   33,   33,   46,   33,   42,   82,   41,   43,   12,
   44,   47,  142,  143,   32,   20,   20,  100,   33,   20,
  145,   61,   11,   68,   40,   72,   72,   72,   72,   72,
   19,   72,   47,   19,   20,   69,   69,   69,   69,   69,
   22,   69,   23,   72,   15,   72,   95,   97,   19,   98,
   26,   99,   28,   69,   26,   69,   18,   45,   29,   18,
   40,   44,   40,   40,   44,   96,   95,   97,   33,   98,
   63,   99,   64,   65,   18,   69,   46,   72,   42,   44,
   41,   43,   33,   44,   33,   33,   70,   69,   26,   46,
   71,   45,   10,   41,   43,  130,   44,   84,   20,   86,
   10,   10,  101,  102,  103,   72,  104,  105,   76,   67,
  129,  113,   19,   44,  114,   20,   25,  131,   48,   75,
   59,   77,   78,   79,   80,    1,    2,    3,    4,    5,
  128,  132,  133,  107,  109,  134,  111,  112,   18,   48,
  135,  136,  137,  138,  144,    4,    2,   39,   43,   44,
   36,   60,   24,   16,   58,   24,   81,  139,   27,  141,
    0,  110,  124,  140,   45,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   45,    0,    0,
    0,    0,    0,    0,    0,   15,    0,    0,   34,   35,
   36,    0,   66,   15,   40,   40,   40,    0,  107,    0,
    0,    1,    2,    3,    4,    5,   37,   12,   38,   39,
    0,    0,   40,    0,   40,   40,   33,   33,   33,    0,
   59,    0,   34,   35,   36,    0,    0,    1,    2,    3,
    4,    5,    0,    0,   33,    0,   33,   33,    0,    0,
   37,    0,   38,   39,    0,    0,   72,   72,   72,   72,
   72,   72,   72,   72,   56,    0,   69,   69,   69,   69,
   69,   69,   69,   69,    0,    0,   87,   88,   89,   90,
   91,   92,   93,   94,    0,    0,    0,   56,    0,    0,
    0,   56,    0,    0,    0,    0,   87,   88,   89,   90,
   91,   92,   93,   94,    0,   34,   35,   36,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   34,   35,
   36,    0,    0,    0,    0,  115,  116,  117,  118,  119,
  120,  121,  122,  123,    0,  125,  126,  127,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   56,   56,    0,    0,    0,    0,
    0,    0,   56,
};
short yycheck[] = {                                      38,
   42,   40,   40,   42,   43,   38,   45,   40,   42,   42,
   43,  123,   45,  257,  258,  259,   59,   59,   30,   49,
   59,   41,   42,   53,    8,    9,   59,   38,   41,   40,
  257,   42,   43,   38,   45,   40,   48,   42,   43,   59,
   45,   26,  136,  137,   22,   40,   41,   59,   59,   44,
  144,   29,  274,   91,   59,   41,   42,   43,   44,   45,
   41,   47,   47,   44,   59,   41,   42,   43,   44,   45,
  123,   47,   91,   59,  257,   61,   42,   43,   59,   45,
  123,   47,   40,   59,  123,   61,   41,  126,  123,   44,
  123,   41,  125,  126,   44,   61,   42,   43,  258,   45,
  125,   47,  125,   93,   59,   40,   38,   93,   40,   59,
   42,   43,  123,   45,  125,  126,   40,   93,  123,   38,
   40,  126,    0,   42,   43,  103,   45,  125,  123,   59,
    8,    9,   41,  125,   59,   39,  257,  257,   42,   40,
  257,   59,  123,   93,   41,  257,   59,  260,   26,   41,
   28,   43,   44,   45,   46,  270,  271,  272,  273,  274,
   44,   44,   41,   67,   68,   93,   70,   71,  123,   47,
   41,   41,   41,   59,  276,    0,    0,  125,  125,   59,
  125,   41,   41,  125,   41,   17,   47,  128,   18,  132,
   -1,   69,   96,  131,  126,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  126,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  257,   -1,   -1,  257,  258,
  259,   -1,  260,  257,  257,  258,  259,   -1,  132,   -1,
   -1,  270,  271,  272,  273,  274,  275,  257,  277,  278,
   -1,   -1,  275,   -1,  277,  278,  257,  258,  259,   -1,
  128,   -1,  257,  258,  259,   -1,   -1,  270,  271,  272,
  273,  274,   -1,   -1,  275,   -1,  277,  278,   -1,   -1,
  275,   -1,  277,  278,   -1,   -1,  262,  263,  264,  265,
  266,  267,  268,  269,   26,   -1,  262,  263,  264,  265,
  266,  267,  268,  269,   -1,   -1,  262,  263,  264,  265,
  266,  267,  268,  269,   -1,   -1,   -1,   49,   -1,   -1,
   -1,   53,   -1,   -1,   -1,   -1,  262,  263,  264,  265,
  266,  267,  268,  269,   -1,  257,  258,  259,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  257,  258,
  259,   -1,   -1,   -1,   -1,   87,   88,   89,   90,   91,
   92,   93,   94,   95,   -1,   97,   98,   99,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  136,  137,   -1,   -1,   -1,   -1,
   -1,   -1,  144,
};
#define YYFINAL 6
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 299
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,"'&'",0,"'('","')'","'*'","'+'","','","'-'",0,"'/'",0,0,0,0,0,0,0,0,0,0,
0,"';'",0,"'='",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'['",
0,"']'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'{'",0,"'}'",
"'~'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,"IDENTIFIER","CONSTANT","SIZEOF","PTR_OP","ARRAY_OP",
"GT_OP","LT_OP","GE_OP","LE_OP","NE_OP","EQ_OP","AND_OP","OR_OP","TYPEDEF",
"INT","CHAR","VOID","STRUCT","IF","ELSE","WHILE","RETURN","FUNCTION",
"DECLARATION","TYPE_SPECIFIER","DECLARATOR","FUNCTION_DEFINITION",
"TYPEDEF_STRUCT","STRUCT_DECL_LIST","DIRECT_DECL","ARRAY_DECL","PARAM",
"COMPOUND","DECL","STATE","NEG","AST","FUNC","EXPR_LIST","PROGRAM","EXPR",
"C_STATE","IF_PREC",
};
char *yyrule[] = {
"$accept : program",
"program : program_aux",
"program_aux : function_definition",
"program_aux : function_definition program_aux",
"program_aux : declaration",
"program_aux : declaration program_aux",
"declaration : type_specifier ';'",
"declaration : type_specifier declarator ';'",
"function_definition : type_specifier declarator compound_statement",
"type_specifier : VOID",
"type_specifier : INT",
"type_specifier : CHAR",
"type_specifier : STRUCT IDENTIFIER",
"type_specifier : STRUCT IDENTIFIER '{' struct_decl_list '}'",
"type_specifier : TYPEDEF STRUCT '{' struct_decl_list '}' IDENTIFIER",
"type_specifier : TYPEDEF STRUCT IDENTIFIER '{' struct_decl_list '}' IDENTIFIER",
"struct_decl_list : type_specifier declarator ';'",
"struct_decl_list : type_specifier declarator ';' struct_decl_list",
"declarator : '*' direct_declarator",
"declarator : direct_declarator",
"direct_declarator : IDENTIFIER",
"direct_declarator : direct_declarator '(' parameter_list ')'",
"direct_declarator : direct_declarator '(' ')'",
"direct_declarator : IDENTIFIER '[' CONSTANT ']'",
"parameter_list : type_specifier declarator",
"parameter_list : type_specifier declarator ',' parameter_list",
"statement : if_statement",
"statement : compound_statement",
"statement : ';'",
"statement : unary_expression '=' expression ';'",
"statement : WHILE '(' expression ')' statement",
"statement : RETURN expression ';'",
"statement : expression ';'",
"if_statement : IF '(' expression ')' statement",
"if_statement : IF '(' expression ')' statement ELSE statement",
"compound_statement : '{' compound_statement_aux '}'",
"compound_statement_aux : declaration_list",
"compound_statement_aux : statement_list",
"compound_statement_aux : declaration_list statement_list",
"compound_statement_aux :",
"declaration_list : declaration",
"declaration_list : declaration declaration_list",
"statement_list : statement statement_list",
"statement_list : statement",
"expression : unary_expression",
"expression : unary_expression '+' unary_expression",
"expression : unary_expression '-' unary_expression",
"expression : unary_expression '*' unary_expression",
"expression : unary_expression '/' unary_expression",
"expression : unary_expression LT_OP unary_expression",
"expression : unary_expression GT_OP unary_expression",
"expression : unary_expression LE_OP unary_expression",
"expression : unary_expression GE_OP unary_expression",
"expression : unary_expression NE_OP unary_expression",
"expression : unary_expression EQ_OP unary_expression",
"expression : unary_expression AND_OP unary_expression",
"expression : unary_expression OR_OP unary_expression",
"expression : '(' expression ')'",
"expression_list : expression",
"expression_list : expression ',' expression_list",
"expression_list :",
"unary_expression : unary_ident",
"unary_expression : '+' unary_ident",
"unary_expression : '-' unary_ident",
"unary_expression : '*' unary_ident",
"unary_expression : '~' unary_ident",
"unary_expression : '&' unary_ident",
"unary_expression : IDENTIFIER PTR_OP ptr_op",
"unary_expression : IDENTIFIER '[' expression ']'",
"ptr_op : IDENTIFIER",
"ptr_op : IDENTIFIER PTR_OP ptr_op",
"unary_ident : CONSTANT",
"unary_ident : IDENTIFIER",
"unary_ident : SIZEOF '(' type_specifier ')'",
"unary_ident : IDENTIFIER '(' expression_list ')'",
};
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH 10000
#endif
#endif
#define YYINITSTACKSIZE 200
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short *yyss;
short *yysslim;
YYSTYPE *yyvs;
int yystacksize;
#line 191 "yacc2.y"

int yyerror(char* e) {
	fprintf(stdout,"%s, line %d\n",e,yylineno);
	return -1;
}

int main() {

	do{
		yyparse();
	} while( !feof(yyin));
	return 0;
}


void evaluate(Node *p) {
	extern int errors, treeop;
	list_info* list;
	list_el* aux;
	int decl;
	int func;

	decl = 0;
	func = 0;
	
	list = (list_info*) malloc (sizeof(list_info));

	list -> first = NULL;
	list -> last = NULL;

	while ( p != NULL ) {
		if ( checkFunction(p) == 1 ) {
			func++;
			aux = newFunction(p->value.sub.n[0]);
			addList(list, aux);
		}
		else
			decl++;

		if ( p->value.sub.num == 1)
			p = NULL;
		else
			p = p -> value.sub.n[1];
	}
	
	printf("Top level: %d declarations.\n",decl);
	printList(list);
}

void printList(list_info* list) {

	list_el* pont;
	info* i;

	pont = list -> first;
	while (pont != NULL) {
		i = pont -> info;
		printf("%s: %d declarations, %d statements, %d binary operations.\n", i -> name ,i -> decl ,i -> stat,i-> bina);
		pont = pont -> next;
	}



}

list_el* newFunction(Node* p) {

	list_el *funct_info;
	int i;

	funct_info = createEl();
	
	
	funct_info -> info -> name = getFunctionName(p->value.sub.n[1]);
	
	for ( i = 0 ; i < p -> value.sub.num ; i++ ) {
		checkNodes(p->value.sub.n[i] , funct_info);		
	}


	return funct_info;
}

char* getFunctionName(Node* p) {
	
	if ( p -> attrib == IDENTIFIER )
		return strdup (p->value.s);
	else
		return getFunctionName(p-> value.sub.n[0]);

}

void checkNodes(Node* p, list_el* el) {
	int b = 0;
	int i;
	int s = 0;

	if ( p == NULL )
		return;
	if ( p->attrib == DECLARATION)
		el -> info -> decl += 1;
	else {
		switch (p -> attrib ) {
			case IF: s = 1; break;
			case RETURN: s = 1; break;
			case WHILE: s = 1; break;
			case EXPR: s = 1; break;
			case '=': s = 1; break;
			case ';': s = 1; break;
			case '+': b = 1; break;
			case '-': b = 1; break;
			case '*': b = 1; break;
			case '/': b = 1; break;
			case '<': b = 1; break;
			case '>': b = 1; break;
			case '[': b = 1; break;
			case ']': b = 1; break;
			case EQ_OP: b = 1; break;
			case OR_OP: b = 1; break;
			case AND_OP: b = 1; break;
		}
		
		el -> info -> stat += s;
		el -> info -> bina += b;
	}

	if ( p -> type != nodeOpr )
		return;

	for ( i = 0 ; i < p -> value.sub.num ; i++ ) {
		checkNodes(p->value.sub.n[i] , el);		
	}
}

list_el* createEl() {
	list_el* aux;

	aux = (list_el*) malloc (sizeof(list_el));
	aux -> info = (info*) malloc (sizeof(info));

	aux -> next = NULL;
	aux -> info -> decl = 0;
	aux -> info -> stat = 0;
	aux -> info -> bina = 0;
	aux -> info -> name = NULL;

	return aux;
}

int addList(list_info* list , list_el* new) {
	if ( list -> first == NULL)
		list -> first = new;
	if ( list -> last != NULL)
		list -> last -> next = new;
	list -> last = new;
	return 1;
}

int checkFunction(Node *p) {
	if (p->value.sub.n[0]->attrib == FUNCTION)
		return 1;
	else
		return 0;
}

#line 565 "y.tab.c"
/* allocate initial stack or double stack size, up to YYMAXDEPTH */
int yyparse __P((void));
static int yygrowstack __P((void));
static int yygrowstack()
{
    int newsize, i;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = yystacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;
    i = yyssp - yyss;
    if ((newss = (short *)realloc(yyss, newsize * sizeof *newss)) == NULL)
        return -1;
    yyss = newss;
    yyssp = newss + i;
    if ((newvs = (YYSTYPE *)realloc(yyvs, newsize * sizeof *newvs)) == NULL)
        return -1;
    yyvs = newvs;
    yyvsp = newvs + i;
    yystacksize = newsize;
    yysslim = yyss + newsize - 1;
    return 0;
}

#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    int yym, yyn, yystate;
#if YYDEBUG
    char *yys;

    if ((yys = getenv("YYDEBUG")) != NULL)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    if (yyss == NULL && yygrowstack()) goto yyoverflow;
    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yysslim && yygrowstack())
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
    goto yynewerror;
yynewerror:
    yyerror("syntax error");
    goto yyerrlab;
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yysslim && yygrowstack())
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 72 "yacc2.y"
{ evaluate(yyvsp[0].n); }
break;
case 2:
#line 74 "yacc2.y"
{	yyval.n = subNode(PROGRAM,1,yyvsp[0].n);	}
break;
case 3:
#line 75 "yacc2.y"
{	yyval.n = subNode(PROGRAM,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 4:
#line 76 "yacc2.y"
{	yyval.n = subNode(PROGRAM,1,yyvsp[0].n);	}
break;
case 5:
#line 77 "yacc2.y"
{	yyval.n = subNode(PROGRAM,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 6:
#line 80 "yacc2.y"
{	yyval.n = subNode(DECLARATION,1,yyvsp[-1].n); }
break;
case 7:
#line 81 "yacc2.y"
{	yyval.n = subNode(DECLARATION,2,yyvsp[-2].n,yyvsp[-1].n);	}
break;
case 8:
#line 84 "yacc2.y"
{	yyval.n = subNode(FUNCTION,3,yyvsp[-2].n,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 9:
#line 87 "yacc2.y"
{	yyval.n = nilNode(VOID);	}
break;
case 10:
#line 88 "yacc2.y"
{	yyval.n = nilNode(INT);	}
break;
case 11:
#line 89 "yacc2.y"
{	yyval.n = nilNode(CHAR);	}
break;
case 12:
#line 90 "yacc2.y"
{	yyval.n = subNode(STRUCT,1, strNode(IDENTIFIER,yyvsp[0].s));	}
break;
case 13:
#line 91 "yacc2.y"
{	yyval.n = subNode(STRUCT,2, strNode(IDENTIFIER,yyvsp[-3].s) , yyvsp[-1].n);	}
break;
case 14:
#line 92 "yacc2.y"
{       yyval.n = subNode(TYPEDEF_STRUCT, 3, nilNode(' '), yyvsp[-2].n, strNode(IDENTIFIER,yyvsp[0].s));	}
break;
case 15:
#line 93 "yacc2.y"
{  yyval.n = subNode(TYPEDEF_STRUCT,3, strNode(IDENTIFIER,yyvsp[-4].s) , yyvsp[-2].n, strNode(IDENTIFIER,yyvsp[0].s));	}
break;
case 16:
#line 96 "yacc2.y"
{	yyval.n = subNode(STRUCT_DECL_LIST,2,yyvsp[-2].n,yyvsp[-1].n);	}
break;
case 17:
#line 97 "yacc2.y"
{	yyval.n = subNode(STRUCT_DECL_LIST,3,yyvsp[-3].n,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 18:
#line 100 "yacc2.y"
{	yyval.n = subNode(DECLARATOR, 2, yyvsp[0].n , NULL);	}
break;
case 19:
#line 101 "yacc2.y"
{	yyval.n = subNode(DECLARATOR, 1, yyvsp[0].n);	}
break;
case 20:
#line 104 "yacc2.y"
{ yyval.n = strNode(IDENTIFIER, yyvsp[0].s);		}
break;
case 21:
#line 105 "yacc2.y"
{ yyval.n = subNode(DIRECT_DECL,2,yyvsp[-3].n,yyvsp[-1].n); 	}
break;
case 22:
#line 106 "yacc2.y"
{ yyval.n = subNode(DIRECT_DECL,1,yyvsp[-2].n);	}
break;
case 23:
#line 107 "yacc2.y"
{ yyval.n = subNode(ARRAY_DECL,2,yyvsp[-3].s,intNode(CONSTANT,yyvsp[-1].i)); }
break;
case 24:
#line 110 "yacc2.y"
{	yyval.n = subNode(PARAM,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 25:
#line 111 "yacc2.y"
{	yyval.n = subNode(PARAM,3,yyvsp[-3].n,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 26:
#line 114 "yacc2.y"
{	yyval.n = yyvsp[0].n;	}
break;
case 27:
#line 115 "yacc2.y"
{	yyval.n = subNode(C_STATE,1,yyvsp[0].n);	}
break;
case 28:
#line 116 "yacc2.y"
{	yyval.n = nilNode(';');		}
break;
case 29:
#line 117 "yacc2.y"
{	yyval.n = subNode('=',2,yyvsp[-3].n,yyvsp[-1].n);	}
break;
case 30:
#line 118 "yacc2.y"
{	yyval.n = subNode(WHILE,2,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 31:
#line 119 "yacc2.y"
{	yyval.n = subNode(RETURN,1,yyvsp[-1].n);	}
break;
case 32:
#line 121 "yacc2.y"
{	yyval.n = subNode(EXPR,1,yyvsp[-1].n);	}
break;
case 33:
#line 124 "yacc2.y"
{	yyval.n = subNode(IF,2,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 34:
#line 125 "yacc2.y"
{	yyval.n = subNode(IF,3,yyvsp[-4].n,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 35:
#line 128 "yacc2.y"
{	yyval.n = subNode(COMPOUND,1,yyvsp[-1].n);	}
break;
case 36:
#line 131 "yacc2.y"
{	yyval.n = yyvsp[0].n;	}
break;
case 37:
#line 132 "yacc2.y"
{	yyval.n = yyvsp[0].n;	}
break;
case 38:
#line 133 "yacc2.y"
{	yyval.n = subNode(DECL,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 39:
#line 134 "yacc2.y"
{	yyval.n = NULL;	}
break;
case 40:
#line 137 "yacc2.y"
{	yyval.n = subNode(DECL,1,yyvsp[0].n);	}
break;
case 41:
#line 138 "yacc2.y"
{	yyval.n = subNode(DECL,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 42:
#line 141 "yacc2.y"
{	yyval.n = subNode(STATE,2,yyvsp[-1].n,yyvsp[0].n);	}
break;
case 43:
#line 142 "yacc2.y"
{	yyval.n = yyvsp[0].n;	}
break;
case 44:
#line 146 "yacc2.y"
{ yyval.n = yyvsp[0].n;			}
break;
case 45:
#line 147 "yacc2.y"
{ yyval.n = subNode('+', 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 46:
#line 148 "yacc2.y"
{ yyval.n = subNode('-', 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 47:
#line 149 "yacc2.y"
{ yyval.n = subNode('*', 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 48:
#line 150 "yacc2.y"
{ yyval.n = subNode('/', 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 49:
#line 151 "yacc2.y"
{ yyval.n = subNode(LT_OP, 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 50:
#line 152 "yacc2.y"
{ yyval.n = subNode(GT_OP, 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 51:
#line 153 "yacc2.y"
{ yyval.n = subNode(LE_OP , 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 52:
#line 154 "yacc2.y"
{ yyval.n = subNode(GE_OP , 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 53:
#line 155 "yacc2.y"
{ yyval.n = subNode(NE_OP , 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 54:
#line 156 "yacc2.y"
{ yyval.n = subNode(EQ_OP , 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 55:
#line 157 "yacc2.y"
{ yyval.n = subNode(AND_OP, 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 56:
#line 158 "yacc2.y"
{ yyval.n = subNode(OR_OP , 2, yyvsp[-2].n, yyvsp[0].n);	}
break;
case 57:
#line 159 "yacc2.y"
{ yyval.n = yyvsp[-1].n;	}
break;
case 58:
#line 162 "yacc2.y"
{	yyval.n = yyvsp[0].n;	}
break;
case 59:
#line 163 "yacc2.y"
{	yyval.n = subNode(EXPR_LIST,2,yyvsp[-2].n,yyvsp[0].n);	}
break;
case 60:
#line 164 "yacc2.y"
{	yyval.n = NULL;	}
break;
case 61:
#line 168 "yacc2.y"
{ yyval.n = yyvsp[0].n;	}
break;
case 62:
#line 169 "yacc2.y"
{ yyval.n = yyvsp[0].n;	}
break;
case 63:
#line 170 "yacc2.y"
{ yyval.n = subNode(NEG,1,yyvsp[0].n);	}
break;
case 64:
#line 171 "yacc2.y"
{ yyval.n = subNode(AST,1,yyvsp[0].n);	}
break;
case 65:
#line 172 "yacc2.y"
{ yyval.n = subNode('~',1,yyvsp[0].n);	}
break;
case 66:
#line 173 "yacc2.y"
{ yyval.n = subNode('&',1,yyvsp[0].n);	}
break;
case 67:
#line 174 "yacc2.y"
{ yyval.n = subNode(PTR_OP,2,strNode(IDENTIFIER,yyvsp[-2].s),yyvsp[0].n);	}
break;
case 68:
#line 175 "yacc2.y"
{ yyval.n = subNode(ARRAY_OP,2,strNode(IDENTIFIER,yyvsp[-3].s),yyvsp[-1].n);	}
break;
case 69:
#line 178 "yacc2.y"
{	yyval.n = strNode(IDENTIFIER,yyvsp[0].s);	}
break;
case 70:
#line 179 "yacc2.y"
{	yyval.n = subNode(PTR_OP,2,strNode(IDENTIFIER,yyvsp[-2].s),yyvsp[0].n);	}
break;
case 71:
#line 183 "yacc2.y"
{	yyval.n = intNode(CONSTANT,yyvsp[0].i);	}
break;
case 72:
#line 184 "yacc2.y"
{	yyval.n = strNode(IDENTIFIER,yyvsp[0].s);	}
break;
case 73:
#line 185 "yacc2.y"
{	yyval.n = subNode(SIZEOF,1,yyvsp[-1].n);	}
break;
case 74:
#line 186 "yacc2.y"
{	yyval.n = subNode(FUNC,2,strNode(IDENTIFIER,yyvsp[-3].s),yyvsp[-1].n);	}
break;
#line 1027 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yysslim && yygrowstack())
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
