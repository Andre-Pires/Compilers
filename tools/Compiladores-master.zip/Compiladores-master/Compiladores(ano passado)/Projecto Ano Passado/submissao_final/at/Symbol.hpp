#ifndef _SYMBOL_HH_
#define _SYMBOL_HH_

class Symbol {
public:
	virtual char *name() = 0;
};

#endif /* _SYMBOL_HH_ */
