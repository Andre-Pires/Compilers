#include "SymbolNode.hpp"

char *SymbolNode::name() { return 0; }
int SymbolNode::integer() { return val; }
