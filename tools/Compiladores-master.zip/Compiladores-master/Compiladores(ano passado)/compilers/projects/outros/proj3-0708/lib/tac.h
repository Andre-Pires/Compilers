#ifndef _TAC_H_
#define _TAC_H_

#include <stdlib.h>
#include "node.h"

void generate(Node *p, FILE *fp, int lev);

#endif
